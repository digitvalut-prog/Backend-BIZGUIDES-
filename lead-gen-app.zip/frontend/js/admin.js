// =========================================================
// LaunchKit — admin.js
// Basic-auth admin dashboard: list, search, sort, export, delete leads.
// =========================================================

(function () {
  'use strict';

  var API_BASE_URL = window.LAUNCHKIT_API_BASE_URL || 'http://localhost:5000';
  var LEADS_ADMIN_ENDPOINT = API_BASE_URL + '/api/admin/leads';
  var STORAGE_KEY = 'launchkit_admin_credential';

  var loginView = document.getElementById('login-view');
  var dashboardView = document.getElementById('dashboard-view');
  var loginForm = document.getElementById('login-form');
  var loginError = document.getElementById('login-error');
  var logoutBtn = document.getElementById('logout-btn');
  var exportBtn = document.getElementById('export-btn');
  var searchInput = document.getElementById('search-input');
  var sortSelect = document.getElementById('sort-select');
  var tbody = document.getElementById('leads-tbody');
  var leadCountEl = document.getElementById('lead-count');

  var allLeads = [];

  function getCredential() {
    return sessionStorage.getItem(STORAGE_KEY);
  }

  function authHeader() {
    var cred = getCredential();
    return cred ? { Authorization: 'Basic ' + cred } : {};
  }

  function showDashboard() {
    loginView.hidden = true;
    dashboardView.hidden = false;
    fetchLeads();
  }

  function showLogin(message) {
    loginView.hidden = false;
    dashboardView.hidden = true;
    if (message) loginError.textContent = message;
  }

  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var user = document.getElementById('admin-username').value.trim();
    var pass = document.getElementById('admin-password').value;
    var cred = btoa(user + ':' + pass);

    loginError.textContent = '';

    fetch(LEADS_ADMIN_ENDPOINT, { headers: { Authorization: 'Basic ' + cred } })
      .then(function (res) {
        if (res.status === 401 || res.status === 403) {
          throw new Error('Invalid username or password.');
        }
        if (!res.ok) throw new Error('Could not reach the server.');
        return res.json();
      })
      .then(function (data) {
        sessionStorage.setItem(STORAGE_KEY, cred);
        allLeads = data.leads || [];
        renderLeads();
        showDashboard();
      })
      .catch(function (err) {
        loginError.textContent = err.message;
      });
  });

  logoutBtn.addEventListener('click', function () {
    sessionStorage.removeItem(STORAGE_KEY);
    showLogin();
  });

  function fetchLeads() {
    tbody.innerHTML = '<tr><td colspan="5" class="admin-empty">Loading…</td></tr>';
    fetch(LEADS_ADMIN_ENDPOINT, { headers: authHeader() })
      .then(function (res) {
        if (res.status === 401 || res.status === 403) {
          sessionStorage.removeItem(STORAGE_KEY);
          showLogin('Session expired. Please sign in again.');
          throw new Error('unauthorized');
        }
        return res.json();
      })
      .then(function (data) {
        allLeads = data.leads || [];
        renderLeads();
      })
      .catch(function () {
        tbody.innerHTML = '<tr><td colspan="5" class="admin-empty">Failed to load leads.</td></tr>';
      });
  }

  function getFilteredSorted() {
    var query = searchInput.value.trim().toLowerCase();
    var sort = sortSelect.value;

    var filtered = allLeads.filter(function (lead) {
      if (!query) return true;
      return (
        (lead.full_name || '').toLowerCase().indexOf(query) !== -1 ||
        (lead.email || '').toLowerCase().indexOf(query) !== -1 ||
        (lead.company || '').toLowerCase().indexOf(query) !== -1
      );
    });

    filtered.sort(function (a, b) {
      if (sort === 'created_at_asc') return new Date(a.created_at) - new Date(b.created_at);
      if (sort === 'full_name_asc') return (a.full_name || '').localeCompare(b.full_name || '');
      return new Date(b.created_at) - new Date(a.created_at); // created_at_desc default
    });

    return filtered;
  }

  function renderLeads() {
    var rows = getFilteredSorted();
    leadCountEl.textContent = rows.length + ' lead' + (rows.length === 1 ? '' : 's');

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="admin-empty">No leads found.</td></tr>';
      return;
    }

    tbody.innerHTML = rows
      .map(function (lead) {
        var date = new Date(lead.created_at);
        var dateStr = isNaN(date) ? '' : date.toLocaleString();
        return (
          '<tr data-id="' + lead.id + '">' +
          '<td>' + escapeHtml(lead.full_name) + '</td>' +
          '<td>' + escapeHtml(lead.email) + '</td>' +
          '<td>' + escapeHtml(lead.company || '—') + '</td>' +
          '<td>' + escapeHtml(dateStr) + '</td>' +
          '<td><button class="row-delete" data-id="' + lead.id + '">Delete</button></td>' +
          '</tr>'
        );
      })
      .join('');
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  searchInput.addEventListener('input', renderLeads);
  sortSelect.addEventListener('change', renderLeads);

  tbody.addEventListener('click', function (e) {
    var btn = e.target.closest('.row-delete');
    if (!btn) return;
    var id = btn.getAttribute('data-id');
    if (!confirm('Delete this lead? This cannot be undone.')) return;

    fetch(LEADS_ADMIN_ENDPOINT + '/' + id, { method: 'DELETE', headers: authHeader() })
      .then(function (res) {
        if (!res.ok) throw new Error();
        allLeads = allLeads.filter(function (l) { return String(l.id) !== String(id); });
        renderLeads();
      })
      .catch(function () {
        alert('Failed to delete lead.');
      });
  });

  exportBtn.addEventListener('click', function () {
    var rows = getFilteredSorted();
    var header = ['ID', 'Full Name', 'Email', 'Company', 'Submitted At'];
    var csvRows = [header.join(',')];

    rows.forEach(function (lead) {
      var line = [
        lead.id,
        csvEscape(lead.full_name),
        csvEscape(lead.email),
        csvEscape(lead.company || ''),
        csvEscape(lead.created_at),
      ];
      csvRows.push(line.join(','));
    });

    var blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'leads-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  function csvEscape(val) {
    var str = String(val === null || val === undefined ? '' : val);
    if (/[",\n]/.test(str)) return '"' + str.replace(/"/g, '""') + '"';
    return str;
  }

  // ---- Boot ----
  if (getCredential()) {
    showDashboard();
  } else {
    showLogin();
  }
})();
