// =========================================================
// LaunchKit — main.js
// Handles: scroll reveal, lead form validation + submission,
// success overlay, nav shadow on scroll.
// =========================================================

(function () {
  'use strict';

  // ---- Config -------------------------------------------------
  // Point this at your backend. In production, set to your deployed API origin.
  var API_BASE_URL = window.LAUNCHKIT_API_BASE_URL || 'http://localhost:5000';
  var LEADS_ENDPOINT = API_BASE_URL + '/api/leads';

  // ---- Footer year ---------------------------------------------
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // ---- Scroll reveal --------------------------------------------
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('is-visible'); });
  }

  // ---- Nav backdrop on scroll -------------------------------------
  var nav = document.getElementById('nav');
  window.addEventListener('scroll', function () {
    if (window.scrollY > 12) nav.style.boxShadow = '0 8px 30px -12px rgba(0,0,0,0.5)';
    else nav.style.boxShadow = 'none';
  });

  // ---- "Get Instant Access" final CTA scrolls to form --------------
  var scrollBtn = document.getElementById('scroll-to-form');
  if (scrollBtn) {
    scrollBtn.addEventListener('click', function (e) {
      e.preventDefault();
      document.getElementById('top').scrollIntoView({ behavior: 'smooth' });
      var nameInput = document.getElementById('fullName');
      setTimeout(function () { nameInput && nameInput.focus(); }, 500);
    });
  }

  // ---- Lead form --------------------------------------------------
  var form = document.getElementById('lead-form');
  var submitBtn = document.getElementById('submit-btn');
  var overlay = document.getElementById('success-overlay');
  var closeOverlayBtn = document.getElementById('close-overlay');
  var successMessage = document.getElementById('success-message');

  var fields = {
    fullName: {
      input: document.getElementById('fullName'),
      error: document.getElementById('fullName-error'),
      validate: function (v) {
        if (!v.trim()) return 'Please enter your full name.';
        if (v.trim().length < 2) return 'Name looks too short.';
        return '';
      },
    },
    email: {
      input: document.getElementById('email'),
      error: document.getElementById('email-error'),
      validate: function (v) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!v.trim()) return 'Please enter your email.';
        if (!re.test(v.trim())) return 'Please enter a valid email address.';
        return '';
      },
    },
  };

  function setFieldError(key, message) {
    var f = fields[key];
    f.error.textContent = message;
    f.input.setAttribute('aria-invalid', message ? 'true' : 'false');
  }

  function validateAll() {
    var valid = true;
    Object.keys(fields).forEach(function (key) {
      var msg = fields[key].validate(fields[key].input.value);
      setFieldError(key, msg);
      if (msg) valid = false;
    });
    return valid;
  }

  Object.keys(fields).forEach(function (key) {
    fields[key].input.addEventListener('blur', function () {
      setFieldError(key, fields[key].validate(fields[key].input.value));
    });
    fields[key].input.addEventListener('input', function () {
      if (fields[key].error.textContent) {
        setFieldError(key, fields[key].validate(fields[key].input.value));
      }
    });
  });

  function setLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtn.classList.toggle('is-loading', isLoading);
  }

  function showSuccess(name) {
    successMessage.textContent =
      'Thanks, ' + (name ? name.split(' ')[0] : 'there') + '! Your Growth Toolkit is on its way — check your inbox.';
    overlay.hidden = false;
    document.body.style.overflow = 'hidden';
  }

  function hideSuccess() {
    overlay.hidden = true;
    document.body.style.overflow = '';
  }

  if (closeOverlayBtn) closeOverlayBtn.addEventListener('click', hideSuccess);
  if (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) hideSuccess();
    });
  }
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay && !overlay.hidden) hideSuccess();
  });

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      if (!validateAll()) return;

      var payload = {
        fullName: fields.fullName.input.value.trim(),
        email: fields.email.input.value.trim(),
        company: document.getElementById('company').value.trim(),
      };

      setLoading(true);

      fetch(LEADS_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
        .then(function (res) {
          return res.json().then(function (data) {
            return { ok: res.ok, status: res.status, data: data };
          });
        })
        .then(function (result) {
          setLoading(false);
          if (!result.ok) {
            var message =
              (result.data && result.data.message) ||
              (result.status === 409
                ? 'This email has already claimed the toolkit.'
                : 'Something went wrong. Please try again.');
            setFieldError('email', result.status === 409 ? message : '');
            if (result.status !== 409) {
              alert(message);
            } else {
              setFieldError('email', message);
            }
            return;
          }
          form.reset();
          showSuccess(payload.fullName);
        })
        .catch(function () {
          setLoading(false);
          alert('Network error — please check your connection and try again.');
        });
    });
  }
})();
