# LaunchKit — Lead Generation Web App

A production-ready lead generation application: a static HTML/CSS/JS landing page with a lead-capture form, and a Node.js/Express + PostgreSQL backend that stores leads and instantly emails a reward via Nodemailer. Includes a password-protected admin dashboard.

```
Visitor → Landing Page → Lead Form → Backend Validation → Save to PostgreSQL → Send Reward Email → Success Screen
```

## Project structure

```
lead-gen-app/
├── frontend/                 # Static HTML/CSS/JS site
│   ├── index.html            # Landing page
│   ├── admin.html            # Admin dashboard
│   ├── css/
│   │   ├── style.css         # Design system + landing page styles
│   │   └── admin.css         # Admin dashboard styles
│   ├── js/
│   │   ├── main.js           # Form validation, submission, scroll reveal
│   │   └── admin.js          # Admin login, table, search, export, delete
│   ├── assets/favicon.svg
│   ├── robots.txt
│   └── sitemap.xml
│
└── backend/                  # Node.js + Express + PostgreSQL API
    ├── server.js              # App entrypoint
    ├── config/db.js           # PostgreSQL pool
    ├── routes/                # leads.js, admin.js
    ├── controllers/           # leadController.js, adminController.js
    ├── services/emailService.js
    ├── templates/rewardEmail.js
    ├── middleware/            # validateLead, rateLimiter, adminAuth, errorHandler
    ├── models/leadModel.js
    ├── database/schema.sql, migrate.js
    ├── utils/logger.js
    └── .env.example
```

## 1. Prerequisites

- Node.js 18+
- PostgreSQL 13+
- An SMTP account (Gmail app password, SendGrid, Mailgun, Postmark, etc.)

## 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env with your DB credentials, SMTP credentials, admin password, etc.
```

Create the database and apply the schema:

```bash
# create the database (adjust user/db name to match your .env)
createdb leadgen_db

# apply schema.sql
npm run migrate
```

Run the API:

```bash
npm run dev      # development, with nodemon auto-reload
npm start        # production
```

The API runs on `http://localhost:5000` by default.

## 3. Frontend setup

The frontend is plain HTML/CSS/JS — no build step required.

```bash
cd frontend
# serve it with any static server, e.g.:
npx serve .
# or just open index.html directly in a browser for local testing
```

By default the frontend calls the API at `http://localhost:5000`. To point it at a different backend (e.g. in production), set this before `main.js`/`admin.js` load, e.g. add to `index.html` and `admin.html`:

```html
<script>window.LAUNCHKIT_API_BASE_URL = "https://api.yourdomain.com";</script>
```

## 4. API documentation

### `POST /api/leads`
Public endpoint. Creates a lead and sends the reward email.

Request body:
```json
{ "fullName": "Ada Lovelace", "email": "ada@startup.com", "company": "Startup Inc." }
```

Responses:
- `201` — `{ "success": true, "message": "...", "data": { "id": 1, "fullName": "...", "email": "..." } }`
- `400` — validation error
- `409` — email already registered
- `429` — rate limited

### `GET /api/admin/leads`
Protected with HTTP Basic Auth (`ADMIN_USERNAME` / `ADMIN_PASSWORD`). Returns `{ success, total, leads: [...] }`.

### `DELETE /api/admin/leads/:id`
Protected. Deletes a lead by id.

### `GET /health`
Unauthenticated health check.

## 5. Security features implemented

- **Helmet** — secure HTTP headers
- **CORS** — restricted to `FRONTEND_URL`
- **express-rate-limit** — general API limiter + a stricter limiter on `/api/leads`
- **express-validator + xss** — input validation and sanitization
- **Parameterized SQL queries** (`pg`) — no string-concatenated SQL, prevents SQL injection
- **HTTP Basic Auth with `crypto.timingSafeEqual`** — admin routes
- **Centralized error handler** — no stack traces leaked in production
- **Winston + Morgan logging** — request and error logs to console and file

## 6. Admin dashboard

Visit `frontend/admin.html`, sign in with `ADMIN_USERNAME` / `ADMIN_PASSWORD` from your `.env`. You can search, sort, export to CSV, and delete leads.

## 7. Analytics placeholders

Add your IDs to `.env` (`GA_MEASUREMENT_ID`, `GTM_CONTAINER_ID`, `GOOGLE_ADS_CONVERSION_ID`, `META_PIXEL_ID`) and insert the corresponding snippets into `frontend/index.html` `<head>` before deploying.

## 8. Deployment notes

- **Backend**: deploy to Render, Railway, Fly.io, or a VPS. Set all `.env` values as environment variables. Use a managed PostgreSQL instance (Render/Neon/Supabase/RDS).
- **Frontend**: deploy the `frontend/` folder as a static site (Netlify, Vercel, Cloudflare Pages, S3+CloudFront). Set `window.LAUNCHKIT_API_BASE_URL` to your backend's public URL.
- Always serve both over HTTPS in production, and set `DB_SSL=true` if your database requires SSL.

## 9. License

MIT — use freely for your own projects.
